<?php /* Silence is golden */
